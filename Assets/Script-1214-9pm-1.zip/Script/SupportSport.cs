﻿using UnityEngine;
using System.Collections;

public class SupportSpot {
    public Vector3 position;
    public double score;
}
