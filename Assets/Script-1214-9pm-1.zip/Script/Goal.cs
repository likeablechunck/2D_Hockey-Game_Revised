﻿using UnityEngine;
using System.Collections;

public class Goal : MonoBehaviour {

    public Vector3 leftPost;
    public Vector3 rightPost;
	public Vector3 center;
    public float depth;
    public Vector3 facing;
	int goalsScored;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
