﻿using UnityEngine;
using System.Collections;

public class ManualPlayer : AIState {

    public override void Enter(StatefulBehaviour behaviour) {

    }

    public override void Exit(StatefulBehaviour behaviour)
    {

    }

    public override void Execute(StatefulBehaviour behaviour)
    {
        Player player = (Player)behaviour;
        float walkingSpeed = 6.0f;
        {
            
        }
        if(Input.GetKey(KeyCode.W))
        {
            //move it up
            //MonoBehaviour.print("move up");
            player.transform.Translate(Vector3.up * Time.deltaTime * walkingSpeed);
            // if i have the ball i should move it too
            if (player.PuckWithinReceivingRange())
            {
                player.puck.owner = player;
                player.puck.Kick(Vector3.up, walkingSpeed);
            }
           
        }
        if (Input.GetKey(KeyCode.D))
        {
            //move it to right
            player.transform.Translate(Vector3.right * Time.deltaTime * walkingSpeed);
            if (player.PuckWithinReceivingRange())
            {
                player.puck.owner = player;
                player.puck.Kick(Vector3.right, walkingSpeed);
            }


        }
        if (Input.GetKey(KeyCode.A))
        {
            //move it to left
            player.transform.Translate(Vector3.left * Time.deltaTime * walkingSpeed);
            if (player.PuckWithinReceivingRange())
            {
                player.puck.Kick(Vector3.left, walkingSpeed);
                player.puck.owner = player;
            }


        }
        if (Input.GetKey(KeyCode.S))
        {
            //move it down
            player.transform.Translate(Vector3.down * Time.deltaTime * walkingSpeed);
            if (player.PuckWithinReceivingRange())
            {
                player.puck.owner = player;
                player.puck.Kick(Vector3.down, walkingSpeed);
            }


        }
        // if space is hit then shoot
        // if p is hit then pass
        // if enter is hit then shoot

        if (player.PuckWithinReceivingRange())
        {
            if (Input.GetKey(KeyCode.Return))
            {
                if (player.team.receiver == null)
                {
                    Player supportme = player.FindSupport();
                    supportme.ChangeState(ScriptableObject.CreateInstance<SupportAttacker>());
                    player.puck.owner = player;
                    player.puck.GetComponent<Rigidbody2D>().velocity = new Vector3(0, 0, 0);
                }
                else {
                    Vector3 kickDirection = player.team.receiver.GetTarget() - player.transform.position;
                    player.puck.Kick(kickDirection, 20.0f);
                    player.puck.owner = player;
                }
            }
            if (Input.GetKey(KeyCode.P) && player.team.supportingPlayer != null)
            {
                Vector3 kickDirection = player.team.supportingPlayer.transform.position - player.puck.transform.position;
                player.puck.Kick(kickDirection, 10.0f);
                player.puck.owner = player;
                MonoBehaviour.print(string.Format("passing the ball to {0}", player.team.supportingPlayer.name));
            }

        }
    }
}
