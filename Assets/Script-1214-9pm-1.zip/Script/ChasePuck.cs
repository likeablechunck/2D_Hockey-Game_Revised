﻿using UnityEngine;
using System.Collections;

public class ChasePuck : AIState {


	public override void Enter(StatefulBehaviour behaviour) {
		Player player = (Player)behaviour;
        player.SetTarget(player.puck.transform.position);
        player.steering.Pursuit(player.puck.transform, new Vector3(5.0f, 5.0f, 0));
            //player.SetTarget(player.puck.transform.position);
            //player.steering.Seek(player.puck.transform.position);
        //} else
        //
        //    player.SetTarget(new Vector3(player.transform.position.x, player.puck.transform.position.y, 0));
        //    player.steering.Seek(new Vector3(player.transform.position.x, player.puck.transform.position.y, 0));
		//player.team.receiver = player;
		//player.team.controllingPlayer = player;
		//double passThreatRadius = 70.0;
		//if (player.InHotRegion () || 
		//    !player.team.IsOpponentWithinRadius (player, passThreatRadius)) {
		//	player.steering.ArriveOn();
		//} else {
		//	player.steering.PursuitOn();
		//}
		
	}
	
	public override void Exit(StatefulBehaviour behaviour) {
        return;
	}
	
	public override void Execute(StatefulBehaviour behaviour) {
        Player player = (Player)behaviour;
        if(player.team.isManual )//&& player.IsControllingPlayer())
        {
            return;
        }
        if (player.PuckWithinReceivingRange())
        {
            MonoBehaviour.print(string.Format("{0} will own this now", player.name));
            player.team.setControllingPlayer(player);
            player.puck.owner = player;
            if (!player.team.isManual)
            {
                player.ChangeState(ScriptableObject.CreateInstance<KickPuck>());
            }
            return;
        }
        if (player.IsClosestTeamMemberToPuck())
        {
            //MonoBehaviour.print(string.Format("{0} kind of close {1}",
            //    player.name,
            //    (player.transform.position - player.puck.transform.position).magnitude));
            Vector3 puckPosition = player.puck.transform.position;
            // if its too close to goal keeper then dont go there
            if (!player.IsTooCloseToGoal())
            {
                //MonoBehaviour.print(string.Format("{0} need to go behind the ball", player.name));
                player.SetTarget(puckPosition);
                player.steering.Seek(player.GetTarget());
            } else
            {
                // this does not make sense. if i am close to puck but not close to gal then
                // stay where i am ?
                player.SetTarget(player.transform.position);
                player.steering.Flee(player.GetTarget());
            }
            
            //else
            //{
            //    player.SetTarget(new Vector3(player.transform.position.x, puckPosition.y, 0));
            //    player.steering.Seek(new Vector3(player.transform.position.x, puckPosition.y, 0));
            //}
            return;
        }
        //if (player.PuckWithinReceivingRange () || !player.team.InControl ()) {
        //	player.ChangeState(new ChasePuck());
        //}
        // i dont have the ball anymore if i had it so lets wait
        player.ChangeState(ScriptableObject.CreateInstance<Wait>());

    }
}
