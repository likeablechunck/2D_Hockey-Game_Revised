﻿using UnityEngine;
using System.Collections;

public class ReceivePuck : AIState {
	public override void Enter(StatefulBehaviour behaviour) {
        //MonoBehaviour.print("arrive enter");
        Player player = (Player)behaviour;
        if (player.team.isManual && player.IsControllingPlayer())
        {
            // do nothing and wait for the ball
        }

        player.team.setReceiver(player);
        double passThreatRadius = 3.0;
		if (player.InHotRegion () || 
			!player.team.IsOpponentWithinRadius (player, passThreatRadius)) {
            // when other player passes the ball it should also call this player.arrive
            //MonoBehaviour.print("arrive here please");
            player.steering.Arrive(player.GetTarget());
		} else {
            //MonoBehaviour.print("change the target now ");

            player.SetTarget(player.puck.transform.position);
            player.steering.Pursuit(player.puck.transform,
                player.puck.GetComponent<Rigidbody2D>().velocity);
		}
	}
	
	public override void Exit(StatefulBehaviour behaviour) {
		return;
	}
	
	public override void Execute(StatefulBehaviour behaviour) {
        //MonoBehaviour.print("arrive execute");
        Player player = (Player)behaviour;
        if (player.PuckWithinReceivingRange() || !player.team.InControl())
        {
            //if (player.PuckWithinReceivingRange () || !player.team.InControl ()) {
            MonoBehaviour.print(string.Format("puck is with me {0} yoogoo", player.name));
            player.team.setReceiver(null);
            player.team.setSupprotingPlayer(null);
            // before changing controlling player set the previous color to white
            player.team.setControllingPlayer(player);
            Player supportme = player.FindSupport();
            supportme.ChangeState(ScriptableObject.CreateInstance<SupportAttacker>());
            if (player.team.isManual)
            {
                // the current controlling player should switch back to wait
                //do nothing. you have the ball now so switch to manual control
                player.team.controllingPlayer.ChangeState(ScriptableObject.CreateInstance<Wait>());
                player.team.setControllingPlayer(player);
                player.ChangeState(ScriptableObject.CreateInstance<ManualPlayer>());
            }
            else {
                player.ChangeState(ScriptableObject.CreateInstance<ChasePuck>());
            }
            return;
		}
        if (player.IsAtTarget())
        {
            //MonoBehaviour.print("2");
            //player.puck.owner = player;
            //player.Trac=kPuck();
            player.velocity = new Vector3(0, 0, 0);
        }
        //else
        //{
        //    // continue the pursuit
        //    //monobehaviour.print("3");
        //    player.SetTarget(player.puck.transform.position);
        //    player.steering.Pursuit(player.puck.transform,
        //        player.puck.GetComponent<Rigidbody2D>().velocity);
        //}
        return;
	}

}
