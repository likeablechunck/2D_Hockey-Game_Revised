﻿using UnityEngine;
using System.Collections;

public class SupportAttacker : AIState {

    public override void Enter(StatefulBehaviour behaviour)
    {
        Player player = (Player)behaviour;
        Vector3 bestSupportingSpot = player.team.DetermineBestSupportingPosition();
        player.SetTarget(bestSupportingSpot);
        player.steering.Arrive(bestSupportingSpot);
        player.team.setSupprotingPlayer(player);
    }

    public override void Exit(StatefulBehaviour behaviour)
    {
        return;
    }

    public override void Execute(StatefulBehaviour behaviour)
    {
        Player player = (Player)behaviour;
        if(!player.team.InControl())
        {
            //MonoBehaviour.print(string.Format("{0} in support not in control", player.name));
            player.SetTarget(player.homeRegion.Center());
            player.steering.Arrive(player.homeRegion.Center());
            return;
        }
        if (!player.IsAtTarget())
        {
            //MonoBehaviour.print(string.Format("im in support not near target {0} ", name));
            //Vector3 target = player.team.DetermineBestSupportingPosition();
            //player.SetTarget(target);
            player.steering.Arrive(player.GetTarget());
            return;
        } else
        {
            //MonoBehaviour.print(string.Format("im in support and at target {0} ", name));
            player.velocity = new Vector3(0, 0, 0);
            //player.team.setReceiver(player);
            // how about supporting player
            player.team.setSupprotingPlayer(player);
            if (!player.IsThreatened())
            {
                player.team.RequestPass(player);
                return;
            }
        }
        //double maxShootingForce = 10.0d;
        //if (player.team.CanShoot(player.transform.position, 
        //    player.team.opponent.goal.center, maxShootingForce))
        //{
        //    //MonoBehaviour.print(string.Format("{0} in support requesting pass from another player", player.name));
        //    player.team.RequestPass(player);
        //    return;
        //}
    }
}
