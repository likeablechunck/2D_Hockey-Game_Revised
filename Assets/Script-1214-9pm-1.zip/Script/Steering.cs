﻿using UnityEngine;
using System.Collections;

public class Steering : MonoBehaviour {

	float moveSpeed = 3.0f;
	float minDistance = 0.00001f;
	float safeDistance = 1f;
    Player player;


    void Start()
    {
        player = gameObject.GetComponent<Player>();
    }

	public bool Seek(Vector3 targetPosition) {
        
            Vector3 direction = targetPosition - transform.position;
            direction.z = 0;
            //transform.rotation = Quaternion.Slerp (transform.rotation, 
            //                                       Quaternion.LookRotation(direction),
            //                                       rotationSpeed * Time.deltaTime);
            if (player.team.IsOpponentWithinRadiusOfPosition(targetPosition, 0.05))
            {
            print("someone there , i dont want to go");
                return true;
            }
                //Vector3 moveVector = direction.normalized * moveSpeed * Time.deltaTime;
                Vector3 moveVector = direction * moveSpeed * Time.deltaTime;
                print(string.Format(" seek : i am {4} here {0} and need to go here {1} direction : {2} moveVector + {3}",
                    transform.position, targetPosition, direction, moveSpeed, name));
                transform.Translate(moveVector);

        return true;
	}

	public bool Flee(Vector3 targetPosition) {
        Vector3 direction = targetPosition - transform.position;
        direction.z = 0;
        if (!player.team.IsOpponentWithinRadius(player, 0.5))
        {
            return true;
        }
        if (direction.magnitude < safeDistance) {
			//transform.rotation = Quaternion.Slerp (transform.rotation, 
			//                                       Quaternion.LookRotation(direction),
			//                                       rotationSpeed * Time.deltaTime);
			Vector3 moveVector = -1 * direction.normalized * moveSpeed * Time.deltaTime;
            if (player.goalKeeper)
            {
                moveVector.x = 0;
            }
            transform.Translate(moveVector);
        }
        return true;
	}

	public bool Arrive(Vector3 targetPosition) {;
        //print(string.Format(" arrive: i am {4} here {0} and need to go here {1} direction : {2} moveVector + {3}",
        //    transform.position, targetPosition, direction, moveVector, name));

            Vector3 direction = targetPosition - transform.position;
            Vector3 moveVector = direction * moveSpeed * Time.deltaTime;
            transform.Translate(moveVector);

        //print(string.Format("moved {0} to {1}", name, transform.position));
        return true;
    }


	public bool Pursuit(Transform pursuit, Vector3 targetSpeed) {
  //      int iterationAhead = 30 ;
		//Vector3 targetFuturePosition = pursuit.transform.position + (targetSpeed * iterationAhead);
		Vector3 direction = pursuit.transform.position - transform.position;
		direction.z = 0;
        moveSpeed = targetSpeed.x;
        return Seek(direction);
        //transform.rotation = Quaternion.Slerp(transform.rotation,
        //                                      Quaternion.LookRotation(direction),
        //                                      rotationSpeed * Time.deltaTime);
        //if(direction.magnitude > minDistance){			
        //	Vector3 moveVector = direction.normalized * moveSpeed * Time.deltaTime;
        //	transform.position += moveVector;
        //}
	}

	public bool Evade(Transform evader, Vector3 targetSpeed) {
        if (gameObject.GetComponent<Player>().goalKeeper)
        {
            return Flee(new Vector3(transform.position.x, evader.position.y, 0));
        }

        int iterationAhead = 30;
		Vector3 targetFuturePosition = evader.transform.position + (targetSpeed * iterationAhead);
		Vector3 direction = targetFuturePosition - transform.position;
		direction.z = 0;
        return Flee(targetFuturePosition);
		//transform.rotation = Quaternion.Slerp(transform.rotation,
		//                                      Quaternion.LookRotation(direction),
		//                                      rotationSpeed * Time.deltaTime);
		//if(direction.magnitude < safeDistance){
		//	Vector3 moveVector = direction.normalized * moveSpeed * Time.deltaTime;
		//	transform.position += moveVector;
		//}
	}
}
