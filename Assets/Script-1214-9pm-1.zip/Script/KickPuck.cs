﻿using UnityEngine;
using System.Collections;

public class KickPuck : AIState {

    public override void Exit(StatefulBehaviour behaviour)
    {
        return;
    }
    public override void Enter(StatefulBehaviour behaviour)
    {

        return;
    }

    public override void Execute(StatefulBehaviour behaviour)
    {
        Player player = (Player)behaviour;
        //if (player.team.receiver != null || player.pitch.GoalKeeperHasPuck())
        //{
        //    player.ChangeState(ScriptableObject.CreateInstance<ChasePuck>());
        //}
        float kickPower = 20.0f;
        float passPower = 10.0f;
        Vector3 goal = player.team.opponent.goal.center;
        if (!player.PuckWithinReceivingRange())
        {
            player.team.setControllingPlayer(null);
            player.SetTarget(player.transform.position);
            player.ChangeState(ScriptableObject.CreateInstance<Wait>());
            return;
        }
        if (player.team.CanShoot(player.puck.transform.position, goal, kickPower))
        {
            Vector3 kickDirection = goal - player.puck.transform.position;
            MonoBehaviour.print(string.Format("shooting {0}", kickDirection));
            player.team.setControllingPlayer(player);
            player.puck.Kick(kickDirection, 20.0f);
            player.SetTarget(player.transform.position);
            player.ChangeState(ScriptableObject.CreateInstance<Wait>());
            return;
        }
        //int minPassDistance = 10;
        //Player receiver;
        //Vector3 puckTarget;
        if (player.IsThreatened() && player.team.supportingPlayer != null)
        {
            Vector3 kickDirection = player.team.supportingPlayer.transform.position - 
                player.transform.position;
            player.puck.Kick(kickDirection, passPower);
            player.team.setControllingPlayer(player);
            MonoBehaviour.print(string.Format("threatened and somebody to support so passing the ball to {0}", player.team.supportingPlayer.name));
            player.SetTarget(player.transform.position);
            player.ChangeState(ScriptableObject.CreateInstance<Wait>());
            player.team.supportingPlayer.ChangeState(ScriptableObject.CreateInstance<ReceivePuck>());
            return;
        }

        if (player.team.receiver != null)
        {

            //MonoBehaviour.print(player.team.receiver.name);
            //Vector3 kickDirection = player.puck.transform.position - player.team.receiver.GetTarget();
            Vector3 kickDirection = player.team.receiver.transform.position - player.transform.position;
            player.team.setControllingPlayer(player);
            MonoBehaviour.print(string.Format("passing the ball to {0}", player.team.receiver.name));
            player.puck.Kick(kickDirection, passPower);
            player.SetTarget(player.transform.position);
            player.team.receiver.ChangeState(ScriptableObject.CreateInstance<ReceivePuck>());
            player.ChangeState(ScriptableObject.CreateInstance<Wait>());
            //Player supportme = player.FindSupport();
            //supportme.ChangeState(ScriptableObject.CreateInstance<SupportAttacker>());
        }
        else
        {
            MonoBehaviour.print("i want to dribble");
            Player supportme = player.FindSupport();
            supportme.ChangeState(ScriptableObject.CreateInstance<SupportAttacker>());
            player.ChangeState(ScriptableObject.CreateInstance<MoveAlong>());
        }
    }
}
