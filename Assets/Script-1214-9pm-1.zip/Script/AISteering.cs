﻿using UnityEngine;
using System.Collections;

public class AISteering : MonoBehaviour {

    string state = "";
    Vector3 moveDirection;
    float moveSpeed;
    Puck targetPuck;
    Player targetPlayer;
    Vector3 targetPosition;
    float seekSpeed;
    float pursuitSpeed;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (state.Equals("arrive"))
        {
            Arrive();
        } else if (state.Equals("pursuitpuck"))
        {
            PursuitPuck();
        } else if (state.Equals("move"))
        {
            Move();
        }
	}


    public void Move()
    {
        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);
        state = "";
    }

    public void MoveTo(Vector3 direction, float speed)
    {
        state = "move";
        moveDirection = direction;
        moveSpeed = speed;
    }

    public void Seek(Vector3 target, float speed)
    {
        Vector3 direction = target - transform.position;
        direction.z = 0;
        float safeDistance = 0.01f;
        if (direction.magnitude < safeDistance)
        {
            Vector3 moveVector = -1 * direction.normalized * speed * Time.deltaTime;
            transform.Translate(moveVector);
        }
    }

    void PursuitPuck()
    {
        state = "pursuitpuck";
        int iterationAhead = 5;
        Vector3 targetVelocity = targetPuck.instantVelocity;
        Vector3 targetFuturePosition = targetPuck.transform.position + targetVelocity * iterationAhead;
        Seek(targetFuturePosition, pursuitSpeed);
    }

    void ArriveOn(Vector3 position, float speed)
    {
        state = "arrive";
        targetPosition = position;
        seekSpeed = speed;
    }

    void Arrive()
    {
        Seek(targetPosition, seekSpeed);
    }

    public void PursuitPuckOn(Puck target, float speed)
    {
        state = "pursuitpuck";
        targetPuck = target;
        pursuitSpeed = speed;
    }

    public void PursuitOff()
    {
        state = "";
    }

    public bool IsPursuitPuckOn()
    {
        return state.Equals("pursuitpuck") ;
    }

    public bool IsArriveOn()
    {
        return state.Equals("arrive");
    }

    public void ArriveOff()
    {
        state = "";
    }

    public bool IsAtTarget()
    {
        float atTargetDistance = 0.001f;
        if (state.Equals("arrive"))
        {
            return ((transform.position - targetPosition).magnitude < atTargetDistance);
        }
        else if (state.Equals("pursuitpuck"))
        {
            return ((transform.position - targetPuck.transform.position).magnitude < atTargetDistance);
        }
        return false;
    }
}
