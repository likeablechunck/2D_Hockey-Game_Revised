﻿using UnityEngine;
using System.Collections;

public class Puck : MonoBehaviour {
	
	// Store ball old position
	// the player that owns the ball at the moment
	public Player owner;
    public Vector3 lastDirection;
    public float directionX;
    public float directionY;
    public Vector3 startingPosition;
    public float speed = 10;
    int dirx = 1;
    public TextMesh ballOwnerTExt;
    int diry = -1;
    public Vector3 instantVelocity;
    Vector3 lastPosition;

	// Use this for initialization
	void Start () {
        // put the ball in the center
        //oldPos = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        instantVelocity = (transform.position - lastPosition) / Time.deltaTime;
        directionX = lastDirection.x;
        directionY = lastDirection.y;
        if (owner != null)
        {
            ballOwnerTExt.text = owner.name;
        } else
        {
            ballOwnerTExt.text = "no one";
        }
        //print(string.Format("puck is at {0}", transform.position));
        bool edgeHit = false;
        if (transform.position.x < -7) 
        {
            transform.position = new Vector3(-6.49f, transform.position.y, 0);
            directionX = lastDirection.x * -1;
            edgeHit = true;
        } else if (transform.position.x > 7)
        {
            directionX = lastDirection.x * -1;
            transform.position = new Vector3(6.49f, transform.position.y, 0);
            edgeHit = true;
        }

        if (transform.position.y > 4)
        {
            directionY = lastDirection.y * -1;
            edgeHit = true;
            transform.position = new Vector3(transform.position.x, 3.49f, 0);
        }
        if (transform.position.y < -4)
        {
            directionY = lastDirection.y * -1;
            edgeHit = true;
            transform.position = new Vector3(transform.position.x, -3.49f, 0);
        }
        if (edgeHit)
        {
            print("edge hit");
            lastDirection = new Vector3(directionX, directionY, 0);
            lastDirection.Normalize();
            print(string.Format("ball is being kicked direction : {0}", lastDirection, speed));
            GetComponent<Rigidbody2D>().AddForce(lastDirection * speed, ForceMode2D.Force);
            return;
        }
        GetComponent<Rigidbody2D>().AddForce(lastDirection * speed, ForceMode2D.Force);


        //if (owner == null)
        //{
        // if puck is in the goal then we need to reset
        //print(string.Format("i dont know where im going but keep going i guess! {0}", lastDirection));
        //transform.Translate(lastDirection.normalized * Time.deltaTime);
        //gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(speed, speed);
        //speed = speed - 0.1f;
        //}
        // if we hit one of the edges bounce back :)

    }

    public bool IsCollidingWithWall() {
		return false;
	}

    public void KickOff()
    {
        transform.position = startingPosition;
    }

	public void Kick(Vector3 direction, float force) {
        lastDirection = direction;
        lastDirection.Normalize();
        speed = force;
        print(string.Format("ball is being kicked direction : {0}", direction, force));
        GetComponent<Rigidbody2D>().AddForce(lastDirection * speed, ForceMode2D.Force);
    }

    public void Dribble(Vector3 direction, float force)
    {
        lastDirection = direction;
        lastDirection.Normalize();
        speed = force;
        print(string.Format("ball is being kicked direction : {0}", direction, force));
        GetComponent<Rigidbody2D>().AddForce(lastDirection * speed, ForceMode2D.Force);
    }

    //public float TimeToCoveryDistance(Vector2 a, Vector2 b, int force) {
    //	return -1f;
    //}
    void OnColisionEnter2D(Collision2D col)
    {
        bool gameFinish = false;
        print("we hit sth b");

        //collisionCounter++;
        /*        if(collisionCounter == 5)
                {
                    speed = Random.Range(1, 20) / 10.0f;
                }
        */
        if (!gameFinish)
        {
            //            fastestRecord.text = "Fastest Time:" + minTime;
            if (col.gameObject.name.StartsWith("top"))
            {
                diry = -1;
                speed++;
                transform.Translate(new Vector3(dirx * speed, diry * speed, 0) * Time.deltaTime);
            }
            else if (col.gameObject.name.StartsWith("bottom"))
            {
                diry = +1;
                speed++;
                transform.Translate(new Vector3(dirx * speed, diry * speed/2, 0) * Time.deltaTime);
            }
            else if (col.gameObject.name.StartsWith("left"))
            {
                speed++;
                dirx = +1;
                transform.Translate(new Vector3(dirx * speed, diry * speed/2, 0) * Time.deltaTime);
            }
            else if (col.gameObject.name.StartsWith("right"))
            {
                dirx = -1;
                speed++;
                transform.Translate(new Vector3(dirx * speed, diry * speed/2, 0) * Time.deltaTime);
            }
        }
    }


}
