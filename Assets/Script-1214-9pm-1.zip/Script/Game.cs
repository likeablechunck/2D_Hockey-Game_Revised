﻿using UnityEngine;
using System.Collections;

public class Game : MonoBehaviour {

    public Team redTeam;
    public Team blueTeam;
    int blueTeamScore;
    int redTeamScore;
    public Pitch pitch;
    public Puck puck;
    Team leftTeam;
    Team rightTeam;
    bool gameStarted = false;

	// Use this for initialization
	void Start () {
        // create 5 players for red team and 5 players for blue team
        redTeam.players = InstantiatePlayers(redTeam, "RedPlayer");
        blueTeam.players = InstantiatePlayers(blueTeam, "BluePlayer");
        leftTeam = redTeam;
        rightTeam = blueTeam;
        redTeam.pitch = pitch;
        blueTeam.pitch = pitch;
        setRedTeamColors();
        setBlueTeamColors();
        leftTeam.isManual = true;
        pitch.StartPeriod(leftTeam, rightTeam);

        // every x seconds we should switch sides

    }


    Player[] InstantiatePlayers(Team team, string prefabName)
    {
        Player p0 = InstantiatePlayer(team, prefabName, "gk");
        p0.goalKeeper = true;
        Player p1 = InstantiatePlayer(team, prefabName, "df1");
        Player p2 = InstantiatePlayer(team, prefabName, "df2");
        Player p3 = InstantiatePlayer(team, prefabName, "fw1");
        Player p4 = InstantiatePlayer(team, prefabName, "fw2");
        return new Player[5] { p0, p1, p2, p3, p4 };
    }

    Player InstantiatePlayer(Team team, string prefabName, string namePostfix)
    {
        GameObject p0 = (GameObject)Instantiate(Resources.Load(prefabName));
        p0.name = team.name + namePostfix;
        p0.GetComponent<Player>().pitch = pitch;
        p0.GetComponent<Player>().team = team;
        p0.GetComponent<Player>().puck = puck;
        p0.GetComponent<Player>().steering = p0.GetComponent<Steering>();
        p0.GetComponent<Player>().textmesh = 
            GameObject.Find(p0.name + "Text").GetComponent<TextMesh>();
        return p0.GetComponent<Player>();
    }

    void setRedTeamColors()
    {
        redTeam.controllingColor = new Color(179, 20, 20);
        redTeam.supportingColor = Color.yellow;
        redTeam.receivingColor = new Color(255, 255, 193);
    }

    void setBlueTeamColors()
    {
        blueTeam.controllingColor = new Color(0, 0, 139);
        blueTeam.supportingColor = Color.cyan;
        blueTeam.receivingColor = new Color(115, 45, 156);
    }


    void kickOff()
    {
        leftTeam.positionPlayersAt(leftTeam.startingRegion);
        leftTeam.clearPlayerRolesAndColors();
        rightTeam.clearPlayerRolesAndColors();
        rightTeam.positionPlayersAt(rightTeam.startingRegion);
        pitch.puck.transform.position = new Vector3(0, 0, 0);
        redTeam.ChangeState(ScriptableObject.CreateInstance<Defending>());
        rightTeam.ChangeState(ScriptableObject.CreateInstance<Attack>());
        redTeam.players[0].ChangeState(ScriptableObject.CreateInstance<GoalKeeper>());
        blueTeam.players[0].ChangeState(ScriptableObject.CreateInstance<GoalKeeper>());
        Team manualTeam = redTeam.isManual ? redTeam : blueTeam;
        manualTeam.setControllingPlayer(manualTeam.players[3]);
        manualTeam.controllingPlayer.ChangeState(ScriptableObject.CreateInstance<ManualPlayer>());
    }

    // Update is called once per frame
    void Update () {
        if (!gameStarted)
        {
            kickOff();
            gameStarted = true;
            return;
        }
        bool scored = false;
        if (pitch.LeftTeamScored(puck.transform.position))
        {
            leftTeam.score++;
            scored = true;
        } else if (pitch.RightTeamScored(puck.transform.position))
        {
            rightTeam.score++;
            scored = true;
        }
        // if ball position is now
        if (scored)
        {
            kickOff();
        }
	}
}
