﻿using UnityEngine;
using System.Collections;

public class Player : StatefulBehaviour {
	public Team team;
	public Steering steering;
	public Puck puck;
	public Pitch pitch;
	public Vector3 velocity;
    public string teamName;
    public Vector3 target;
    public FieldRegion homeRegion;
    public bool goalKeeper = false;
    public AISteering steer;

    public TextMesh textmesh;
	
	public void TrackPuck() {
        //puck.owner = this;
        //team.controllingPlayer = this;
	}

    void OnColisionEnter2D(Collision2D col)
    {
        print(string.Format("{0} hit sth", name));
    }



    public bool InHotRegion() {
		return false;
	}



	public bool IsAtTarget() {
        //print(string.Format("{0} reached target {1}? {2}", name, target, (transform.position - target).magnitude < 0.1));
        //return ((transform.position - target).magnitude == 0);
        return ((transform.position - target).magnitude < 0.001);
    }

    public bool IsNearTarget()
    {
        //print(string.Format("{0} near target ? {1} {2}", name, target, (transform.position - target).magnitude < 1));
        return ((transform.position - target).magnitude == 0);
    }

	public bool IsControllingPlayer() {
        return team.controllingPlayer == this;
	}

	public bool IsAheadOfAttacker() {
        if (team.goal.facing.x == 1)
        {
            // this is the left team attacking
            if (team.controllingPlayer != null && transform.position.x > team.controllingPlayer.transform.position.x)
            {
                return true;
            }
        } else
        {
            if (team.controllingPlayer != null && transform.position.x < team.controllingPlayer.transform.position.x)
            {
                return true;
            }
        }
        return false;
	}

	public bool IsClosestTeamMemberToPuck() {
        Player closest = team.GetClosestPlayerToBall();
        return closest.name.Equals(name);
    }


    public bool IsTooCloseToGoal()
    {
        return (transform.position - team.goal.leftPost).magnitude < 0.5 ||
            (transform.position - team.opponent.goal.leftPost).magnitude < 0.5;
    }

    public bool InTheField(float minXDistance, float minYDistance)
    {
        return (transform.position.x - pitch.leftTop.x) > minXDistance &&
            minXDistance < pitch.leftTop.x + pitch.width - transform.position.x &&
            minYDistance < pitch.leftTop.y - transform.position.y &&
            transform.position.y - (pitch.leftTop.y - pitch.height) > minYDistance;
    }

    public bool IsReadyForNextKick()
    {
        return true;
    }

    public Player FindSupport()
    {
        Vector3 bestSupportingSpot = team.DetermineBestSupportingPosition();
        float minSupportDistance = Mathf.Infinity;
        Player closestPlayer = null;
        if (team.players != null)
        {
            foreach (Player player in team.players)
            {
                if (player == this || player.goalKeeper)
                {
                    continue;
                }
                if ((player.transform.position - bestSupportingSpot).magnitude < minSupportDistance)
                {
                    closestPlayer = player;
                }
            }
        }
        return closestPlayer;
    }

    public bool IsThreatened()
    {
        // if any of the other players are within distance of 1 from him
        Player[] opponents = team.opponent.players;
        foreach(Player opponent in opponents)
        {
            // is the other player in front of him ?
            if (team.goal.facing.x == 1 && 
                opponent.transform.position.x > transform.position.x &&
                (transform.position - opponent.transform.position).magnitude < 1)
            {
                //print(string.Format("{0} is threatened", name));
                return true;
            }
            if (team.goal.facing.x == -1 &&
                opponent.transform.position.x < transform.position.x &&
                (transform.position - opponent.transform.position).magnitude < 1)
            {
                //print(string.Format("{0} is threatened", name));
                return true;
            }
        }
        return false;
    }

    public bool PuckWithinGoalKeeperRange()
    {
        if (team.goal.facing.x == -1)
        {
            //return transform.position.x > puck.transform.position.x
            //    //&& transform.position.x - puck.transform.position.x <= 0.395 
            //    && transform.position.x - puck.transform.position.x <= 0.405
            //    && transform.position.y - puck.transform.position.y <= 0.48;
            ////&& transform.position.y - puck.transform.position.y <= 0.28;
            return (transform.position.x > puck.transform.position.x &&
                (transform.position - puck.transform.position).magnitude < 0.4);
        }
        else
        {
            //return transform.position.x < puck.transform.position.x
            //    //&& puck.transform.position.x - transform.position.x == 0.227
            //    && puck.transform.position.x - transform.position.x < 0.300
            //    && puck.transform.position.y < transform.position.y
            //    && transform.position.y - puck.transform.position.y <= 0.48;
            ////&& transform.position.y - puck.transform.position.y <= 0.28;
            return (transform.position.x < puck.transform.position.x &&
                (transform.position - puck.transform.position).magnitude < 0.4);
        }
    }
    public bool PuckWithinReceivingRange()
    {        // if its left team then puck should be close and its x should be > player x
        // if its right team puck should be close and its x should be 
        // make sure x and y are very close

        if (team.goal.facing.x == -1)
        {
            //return transform.position.x > puck.transform.position.x
            //    //&& transform.position.x - puck.transform.position.x <= 0.395 
            //    && transform.position.x - puck.transform.position.x <= 0.405
            //    && transform.position.y - puck.transform.position.y <= 0.48;
            ////&& transform.position.y - puck.transform.position.y <= 0.28;
            return (transform.position.x > puck.transform.position.x &&
                (transform.position - puck.transform.position).magnitude < 0.5);
        }
        else
        {
            //return transform.position.x < puck.transform.position.x
            //    //&& puck.transform.position.x - transform.position.x == 0.227
            //    && puck.transform.position.x - transform.position.x < 0.300
            //    && puck.transform.position.y < transform.position.y
            //    && transform.position.y - puck.transform.position.y <= 0.48;
            ////&& transform.position.y - puck.transform.position.y <= 0.28;
            return (transform.position.x < puck.transform.position.x &&
                (transform.position - puck.transform.position).magnitude < 0.5);
        }
    }

    public void SetTarget(Vector3 target)
    {
        Vector3 modifiedTarget = new Vector3(target.x, target.y, 0);
        // if ball is near target then fix up the target so that i can shoot it
        if ((puck.transform.position - target).magnitude < 0.1)
        {
            if (team.goal.facing.x == -1)
            {
                modifiedTarget.x = target.x + 0.390f;
                modifiedTarget.y = target.y + 0.27f;

            }
            else
            {
                modifiedTarget.x = target.x - 0.200f;
                modifiedTarget.y = target.y + 0.27f;
            }
        }

        this.target = modifiedTarget;
    }

    public Vector3 GetTarget()
    {
        return this.target;
    }

}
